import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Das sind die Hindernisse die sich in der Welt befinden.
 * Durch diese muss unser Flappybird versuchen zu fliegen ohne sie zu berühren.
 * 
 * @author Lenujan Baskaran 
 * @version 1.0
 */
public class Pipe extends Actor
{
    private static int score = 0;
    /**
     * Bild und position für Pipe Level 1 wird festgelegt.
     * 
     */
    public Pipe(){
        setImage(new GreenfootImage("pipe.png"));
        GreenfootImage image = getImage();
        image.scale(500, 900);
        setLocation(600, Greenfoot.getRandomNumber(250)+50);
        score= 0;
    }
    /**
     * Hier wird festgelegt wie die Pipes spawnen.
     * Bei erreichen von 5 Punkten wir Level 2 angezeigt.
     */
    public void act()
    {
        // Pipes spwan level 1
        setLocation(getX() - 1, getY());
        if(getX() <= 1){
            setLocation(getX() + 600, Greenfoot.getRandomNumber(250)+50);
            score++;
        }
        //Level 2 pipe spawn, Level 2 Anzeige
        if(score >=5){
            setImage(new GreenfootImage("pipeLevel2.0.png"));
            GreenfootImage image = getImage();
            image.scale(500, 900);
            setLocation(getX() - 2, getY());
        }
    }
}

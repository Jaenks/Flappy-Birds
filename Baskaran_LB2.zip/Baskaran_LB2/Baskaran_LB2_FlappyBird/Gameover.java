import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Dieser Bildschirm soll zeigen, dass man verloren hat weil man an etwas angeschossen ist.
 * 
 * @author Lenujan Baskaran 
 * @version 1.0
 */
public class Gameover extends Actor
{
    /**
     * Zeigt Gameover, wenn spiel vorbei ist
     */
    public void act()
    {
        // Add your action code here.
    }
}

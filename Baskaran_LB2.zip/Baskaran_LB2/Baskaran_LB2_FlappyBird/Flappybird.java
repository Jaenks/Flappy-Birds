import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Dies ist unser Flappybird. Er versucht durch die Pipes durchzufliegen um soviele Punkte wie möglich zu sammeln.
 * 
 * @author Lenujan Baskaran
 * @version 1.0
 */
public class Flappybird extends Actor
{
    private double g = 1;
    private int y = 300;
    private boolean haspressed = false;
    private boolean isalive = true;
    private boolean isacross = false;
    private boolean hasaddscore = false;
    /**
     * Platziert den Vogel
     */
    public Flappybird(){
        GreenfootImage image = getImage();
        image.scale(50, 40);
    }

    /**
     * Aktion: Hüpfen mit Leertaste gedrückt ist.
     * Wenn Pipe berührt oder Kante berührt wird Flappybird entfernen und Gameover wird angezeigt.
     */

    public void act()
    {
        // Wenn Leertaste gedrückt ist
        if(spacePressed()){
            g=-2;
        }
        g +=0.1;
        y += g;
        setLocation(getX(), (int)(y));

        if(isTouchpipe()){
            isalive = false;
        }
        //Wenn man mit Flappybird an den Rand rand kommt.
        if(isAtEdge()){
            Greenfoot.playSound("peng.mp3");
            isalive = false;
        }
        //Wenn man verliert
        if(!isalive){
            getWorld().addObject(new Gameover(), 300, 200);
            getWorld().removeObject(this);
        }
        //Wenn ein Punkt erzielt wurde
        if(!hasaddscore && isacross && isalive){
            Greenfoot.playSound("score.mp3");
            Score.add(1);
        }
        hasaddscore = isacross;
    }

    /**
     * Prüft, ob die Leertaste gedrückt und reagiert, falls dies zutrifft.
     * Falls dies zutrifft spielt er Sound ab.
     * 
     * @return True wenn Leertaste gedrückt ist, falsch wenn nicht
     */
    //Gibt Zurück ob die Leertaste gedrückt ist
    public boolean spacePressed(){
        boolean pressed = false;
        if(Greenfoot.isKeyDown("space")){
            if(!haspressed){ //Gibt nicht true zurück, wenn Leertaste nicht losgelassen wird
                Greenfoot.playSound("flay.mp3");
                pressed = true;
            }
            haspressed = true;
        }else{
            haspressed = false; //Leertaste gedrückt
        }
        return pressed;
    }

    /**
     * Prüft, ob wir eine Pipe berühren.
     * Spielt sound ab falls Pipe berührt wird.
     * 
     * @return True wen Pipe berührt wird, falsch wenn nicht.
     */
    //Erkennen einer Kollision
    public boolean isTouchpipe(){
        isacross = false;
        for(Pipe pipe : getWorld().getObjects(Pipe.class)){
            if(Math.abs(pipe.getX() - getX()) < 60 ){
                if(Math.abs(pipe.getY() + 30 - getY()) > 37){
                    Greenfoot.playSound("peng.mp3");
                    isalive = false;
                }

                isacross = true; //Eine Kollision hat stattgefunden
            }
        }
        return !isalive;
    }
}

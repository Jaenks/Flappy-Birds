import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Hier wir angezeigt auf welchem Level man sich befindet und wieviel Punkte man aktuell hat.
 * 
 * @author Lenujan Baskaran 
 * @version 1.0
 */
public class Score extends Actor
{
    //Score und Leben Variable
    public static int score;
    public static int life;
    /**
     * Hier wird Festgelegt mit wieviel Punkten/Leben wir starten.
     */
    public Score(){
        //Initialisieren
        score = 0;
        life = 1;
    }
    
    /**
     * Hier wird definiert wo und wie gross die Punktzahl, Level und Leben angezeigt wird.
     */
    public void act()
    {
        World myWorld = getWorld();
        myWorld.showText("Score: " + score + " Life: " + life, 300, 100);
        if (score < 5) { //Wenn Punktestand kleiner als 5 ist
            myWorld.showText("Level 1", 100, 50);
        } else { //Wenn Punktestand grösser als 5 ist
            myWorld.showText("Level 2", 100, 50);
        }
        // Add your action code here.
    }
    /**
     * fügt den gewonnen Punkt zu dem Aktuellen Punktestand.
     * 
     * @param num der Punkt der hinzugefügt wird
     */
    public static void add(int num){
        score += num;
    }
}

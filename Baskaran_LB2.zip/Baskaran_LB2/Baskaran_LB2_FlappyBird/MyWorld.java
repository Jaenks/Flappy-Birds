import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * MyWorld ist der Schauplatz für unser Szenario "Flappy Bird".
 * Es ist der Ort, an dem der Vogel versucht den Pipes auszuweichen, um so Punkte zu sammeln.
 * 
 * @author Lenujan Baskaran
 * @version 1.0
 */
public class MyWorld extends World
{

    /**
     * Konstruktor: die Anfangsobjekte einrichten.
     * 
     */
    public MyWorld()
    {    
        //Alle platzierungen bevor das Spiel startet
        super(600, 400, 1); 
        addObject(new Flappybird(), 100, 300);
        addObject(new Pipe(), 300, 150);
        addObject(new Pipe(), 600, 150);
        addObject(new Score(), 300, 100);
    }
}

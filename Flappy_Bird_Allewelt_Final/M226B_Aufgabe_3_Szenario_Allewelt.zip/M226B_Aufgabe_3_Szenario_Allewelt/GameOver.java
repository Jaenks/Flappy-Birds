import greenfoot.*;

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse GameOver.
 * 
 * @author Jan Allewelt
 * @version 1
 */

public class GameOver extends World
{
    public GameOver()
    {   
        /**
         * Bild grösse definieren
         */
        
        super(800, 400, 1); 
    }
}
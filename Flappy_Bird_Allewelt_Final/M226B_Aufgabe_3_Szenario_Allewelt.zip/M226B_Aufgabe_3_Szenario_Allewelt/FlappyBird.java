import greenfoot.*;

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse GameOver.
 * 
 * @author Jan Allewelt
 * @version 1
 */

public class FlappyBird extends Actor
{
    private double a = 1;
    private int b = 200;
    private int scoreCountDown = 60;
    private boolean haspressed = false;
    private boolean isalive = true;
    private boolean isacross = false;
    private int invincibleTime = 0;
    public FlappyBird()
    {
       /**
        * Flappy grösser definieren
        */
       
       GreenfootImage image = getImage();
       image.scale(50,40);
    }
    public void act() 
    {
          if(scoreCountDown > 0)
          {
            /**
             * Wenn Score grösser als 0 ist anzeigen
             */
            
            scoreCountDown--;
          }
          else
          {
            /**
             * ScoreCountDown 60 Sekunden, nach 60 Sekunden bumpCount 1 Punkte (wird gebraucht für den Aktor Bar, für die Anzeige der Punkte)
             */
            
            scoreCountDown = 60;
            MyWorld myWorld = (MyWorld)getWorld();
            myWorld.getBar().bumpCount(1);
          }   
          if(spacePressed())
          {
            
            a=-2;
          }
          a+=0.1;
          b+=a;
          setLocation(getX(), (int)(b));  
          
          if(isTouching(Heart.class))
          {
              /**
               * Verhalten vom Falppy definieren beim Berühren von einem Herz
               */
              
              invincibleTime = 120;
              GreenfootImage image = new GreenfootImage("clipart2324082.png");
              image.scale(50,40);
              setImage(image);
          }
          if(invincibleTime > 0)
          {
              invincibleTime--;
              return;
          }
          if(invincibleTime == 0)
          {
              /**
               * == steht für gleich wie, beduetet wenn die "invincibleTime" abgelaufen ist, wieder normaler Flappy zeigene
               */
              
              GreenfootImage image = new GreenfootImage("flappybird.png");
              image.scale(50,40);
              setImage(image);
          }
          if(isTouchPipe())
          {  
            isalive = false;   
          }
          if(!isalive)
          {
            /**
             * Wenn Falppy die Pipe berührt, wird der Flappy entfernt und der GameOver Screen gesetzt  
             */
             
            getWorld().removeObject(this); 
            Greenfoot.setWorld(new GameOver());
          }
    }    
    public boolean spacePressed()
    {
          boolean pressed = false;
          if(Greenfoot.isKeyDown("Space"))
          {
          if(!haspressed)
          {
             pressed = true;
          }
          haspressed = true;
          }
          else
          {
             haspressed = false;
          }
          return pressed;
    }
    public boolean isTouchPipe()
    {
          isacross = false;
          for(Pipe pipe : getWorld().getObjects(Pipe.class))
          {
             if(Math.abs(pipe.getX() - getX()) < 69)
             {
                if(Math.abs(pipe.getY() + 30 - getY()) > 37)
                {
                    isalive = false;
                }
                isacross = true;
             } 
          }
          return !isalive;
    }
}

import greenfoot.*;

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse GameOver.
 * 
 * @author Jan Allewelt
 * @version 1
 */

public class Bar extends Actor
{
    /**
     * Bar definieren
     */
    
    private int count = 0;
    public Bar() 
    { 
        /**
         * Image ist die Bar die unten defieniert wird, mit Update wird die Bar aktulisiert
         */
        
        updateImage();
    } 
    public void bumpCount(int amount) 
    { 
        /**
         * Count definieren für spätere Dasrtellung in der Bar
         */
        
        count += amount; 
        updateImage();
    }
    public int getCounter()
    {
        /**
         * Rückgabe Bar
         */
        
        return count;
    }
    private void updateImage()
    {
        /**
         * Anordnung und Darstellung der Bar definieren
         */
        
        setImage(new GreenfootImage("    " +count + " Points   ", 50, Color.WHITE, Color.BLACK)); 
    }
}


import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot und MouseInfo)

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse GameOver.
 * 
 * @author Jan Allewelt
 * @version 1
 */

public class Heart extends Actor
{
    public Heart()
    {
       /**
        * Gadget (Herz) grösse definieren
        */
       
       GreenfootImage image = getImage();
       image.scale(30,30);
    }
    public void act() 
    {
        /**
         * Definieren wann und wo das Herz auf dem Spielfeld erscheint, get(x) mit -1 definieren
         */
        
        setLocation(getX()-1, getY());
        if(getX() <= 1)
        {
            /**
             * Wenn get(x) kleiner ist als 1 setzten wir unten mit getRandomNubmer wo das Herz auf der X Achse erscheinen soll
             */
            
            setLocation(getX() + 600, Greenfoot.getRandomNumber(250)+50);
        } 
        MyWorld myWorld = (MyWorld)getWorld();
        if(myWorld.getBar().getCounter() > 15)
        {
            setLocation(getX()-2, getY());
        }
    }    
}
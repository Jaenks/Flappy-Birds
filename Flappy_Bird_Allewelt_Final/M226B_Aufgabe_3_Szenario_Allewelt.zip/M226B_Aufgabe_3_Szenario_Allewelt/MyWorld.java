import greenfoot.*;

/**
 * Ergänzen Sie hier eine Beschreibung für die Klasse GameOver.
 * 
 * @author Jan Allewelt
 * @version 1
 */

public class MyWorld extends World
{
    Bar bar;
    public MyWorld()
    {   
        /**
         * Definieren welche Aktoren erscheinen, in welcher grösse
         */
    
        super(600, 400, 1); 
        bar = new Bar();
        addObject(new FlappyBird(), 100, 200);
        addObject(new Pipe(), 300, 150);
        addObject(new Pipe(), 600, 150);
        addObject(new Heart(), 450,150);
        addObject(bar, 95,20);
    }
    public Bar getBar()
    {
        /**
         * Rückgabe Bar
         */
        
        return bar;
    }
    public void act()
    {
        if(bar.getCounter() > 15)
        {
            /**
             * Level zwei definieren, beim ereichen von 25 Punkten der Hintergrund ersetzten
             */
            
            GreenfootImage imageHard = new GreenfootImage("background - hard.jpg");
            setBackground(imageHard);
        }
    }
}